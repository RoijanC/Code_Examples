# Model for the codes
class Code < ActiveRecord::Base
		validates :code, presence: true
end
