# README
# This file determines what is needed to accomplish the project

* Add password confirmation before deleting user

* Encrypt the admin code
