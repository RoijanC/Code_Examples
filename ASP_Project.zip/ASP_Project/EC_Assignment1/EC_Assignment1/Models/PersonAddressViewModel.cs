﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EC_Assignment1.Models
{
    public class PersonAddressViewModel
    {
        // GET: PersonAddress
        public Person p { get; set; }
        public IEnumerable<EC_Assignment1.Address> a { get; set; }

        public PersonAddressViewModel(Person p, IEnumerable<EC_Assignment1.Address> a)
        {
            this.p = p;
            this.a = a;
        }
    }
}