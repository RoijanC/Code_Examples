﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EC_Assignment1.Controllers
{
    public class CountryController : Controller
    {
        // GET: Country
        public ActionResult Index()
        {
            ContactDataContext contact = new ContactDataContext();

            var country = from c in contact.Countries
                          select c;

            return View(country);
        }

        // GET: Country/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Country/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Country/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                ContactDataContext contact = new ContactDataContext();

                Country data = new Country();
                data.country_code = collection["country_code"];
                data.country_name = collection["country_name"];
                contact.Countries.InsertOnSubmit(data);

                contact.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Country/Edit/5
        public ActionResult Edit(int id)
        {
            ContactDataContext contact = new ContactDataContext();

            var country = (from c in contact.Countries
                           where c.Id == id
                           select c).First();

            return View(country);
        }

        // POST: Country/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                ContactDataContext contact = new ContactDataContext();

                var country = (from c in contact.Countries
                              where c.Id == id
                              select c).Single();

                country.country_code = collection["country_code"];
                country.country_name = collection["country_name"];
                contact.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Country/Delete/5
        public ActionResult Delete(int id)
        {
            ContactDataContext contact = new ContactDataContext();

            var country = from c in contact.Countries
                          where c.Id == id
                          select c;
            Country c_value = country.Single();

            var address = from a in contact.Addresses
                          where a.CountryId == c_value.Id
                          select a;

            contact.Addresses.DeleteAllOnSubmit(address);
            contact.Countries.DeleteAllOnSubmit(country);
            contact.SubmitChanges();

            return RedirectToAction("Index");
        }

        // POST: Country/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
