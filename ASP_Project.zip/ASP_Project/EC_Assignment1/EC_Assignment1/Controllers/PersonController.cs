﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EC_Assignment1.Controllers
{
    public class PersonController : Controller
    {
        // GET: Person
        public ActionResult Index()
        {
            ContactDataContext contact = new ContactDataContext();

            var person = from p in contact.Persons
                         select p;
            return View(person);
        }

        // GET: Person/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Person/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Person/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                ContactDataContext contact = new ContactDataContext();

                Person data = new Person();
                data.FirstName = collection["FirstName"];
                data.MiddleName = collection["MiddleName"];
                data.LastName = collection["LastName"];
                data.Company = collection["Company"];

                contact.Persons.InsertOnSubmit(data);

                contact.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Person/Edit/5
        public ActionResult Edit(int id)
        {

            ContactDataContext contact = new ContactDataContext();

            var person = (from p in contact.Persons
                          where p.Id == id
                          select p).First();

            return View(person);
        }

        // POST: Person/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                ContactDataContext contact = new ContactDataContext();

                var person = (from p in contact.Persons
                              where p.Id == id
                              select p).Single();

                person.FirstName = collection["FirstName"];
                person.MiddleName = collection["MiddleName"];
                person.LastName = collection["LastName"];
                person.Company = collection["Company"];

                contact.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Person/Delete/5
        public ActionResult Delete(int id)
        {
            ContactDataContext contact = new ContactDataContext();

            var person = from p in contact.Persons
                          where p.Id == id
                          select p;
            Person p_value = person.Single();
            var address = from a in contact.Addresses
                          where a.PersonId == p_value.Id
                          select a;

            contact.Addresses.DeleteAllOnSubmit(address);
            contact.Persons.DeleteAllOnSubmit(person);
            contact.SubmitChanges();

            return RedirectToAction("Index");
        }

        // POST: Person/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
