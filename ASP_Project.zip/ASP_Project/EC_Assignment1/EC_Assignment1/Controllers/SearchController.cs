﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EC_Assignment1.Controllers
{
    public class SearchController : Controller
    {
        // GET: Search
        [HttpGet]
        public ActionResult Index(String id)
        {
            ContactDataContext contact = new ContactDataContext();
            if (!id.Equals(""))
            {
                Person person = (from p in contact.Persons
                where p.FirstName.Contains(id) || p.MiddleName.Contains(id) || p.LastName.Contains(id)
                select p).Single();

                return RedirectToAction("../Address/Index/" + person.Id);
            }
            return RedirectToAction("../");


        }
    }
}