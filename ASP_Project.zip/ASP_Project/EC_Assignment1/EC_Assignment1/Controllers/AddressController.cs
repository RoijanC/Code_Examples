﻿using EC_Assignment1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EC_Assignment1.Controllers
{
    public class AddressController : Controller
    {
        // GET: Address
        public ActionResult Index(int PersonId)
        {
            ContactDataContext contact = new ContactDataContext();

            Person person = (from p in contact.Persons
                             where p.Id == PersonId
                          select p).First();

            var address = from a in contact.Addresses
                          where a.PersonId == PersonId
                          select a;

            var countries = from c in contact.Countries
                            select c;

            ViewData["countries"] = countries;

            return View(new PersonAddressViewModel(person,address));
        }

        // GET: Address/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Address/Create
        public ActionResult Create()
        {
            ContactDataContext contact = new ContactDataContext();


            var countries = from c in contact.Countries
                            select c;
            ViewData["countries"] = countries;
            return View();
        }

        // POST: Address/Create
        [HttpPost]
        public ActionResult Create(int PersonId, FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                ContactDataContext contact = new ContactDataContext();

                Country country =   (from c in contact.Countries
                                     where c.country_code.Equals(collection["country_code"])
                                     select c).Single();          
            
                Address data = new Address();
                data.PersonId = PersonId;
                data.Description = collection["Description"];
                data.StreetAddress = collection["StreetAddress"];
                data.City = collection["City"];
                data.State = collection["State"];
                data.Zip = collection["Zip"];
                data.CountryId = Convert.ToInt32(country.Id);

                contact.Addresses.InsertOnSubmit(data);

                contact.SubmitChanges();

                return RedirectToAction("../" + PersonId);
            }
            catch
            {
                return View();
            }
        }

        // GET: Address/Edit/5
        public ActionResult Edit(int id)
        {
            ContactDataContext contact = new ContactDataContext();

            var address = (from a in contact.Addresses
                           where a.Id == id
                           select a).First();

            var countries = from cs in contact.Countries
                            select cs;

            Country theCountry = (from c in contact.Countries
                         where c.Id == address.CountryId
                         select c).First();



            ViewData["countries"] = countries;
            ViewData["theAddress"] = theCountry.country_code;

  
                          

            return View(address);
        }

        // POST: Address/Edit/5
        [HttpPost]
        public ActionResult Edit(int PersonId, int id, FormCollection collection)
        {
            try
            {
                ContactDataContext contact = new ContactDataContext();

                var address = (from p in contact.Addresses
                               where p.Id == id
                               select p).Single();

                Country country = (from c in contact.Countries
                                   where c.country_code.Equals(collection["country_code"])
                                   select c).Single();

                address.Description = collection["Description"];
                address.StreetAddress = collection["StreetAddress"];
                address.City = collection["City"];
                address.State = collection["State"];
                address.Zip = collection["Zip"];
                address.CountryId = Convert.ToInt32(country.Id);

                Address data = address;

                contact.SubmitChanges();

                return RedirectToAction("../" + PersonId);
            }
            catch
            {
                return View();
            }
        }

        // GET: Address/Delete/5
        public ActionResult Delete(int id)
        {
            ContactDataContext contact = new ContactDataContext();

            var address = from a in contact.Addresses
                          where a.Id == id
                          select a;

            Address data = address.Single();

            contact.Addresses.DeleteAllOnSubmit(address);
            contact.SubmitChanges();

            return RedirectToAction("../" + data.PersonId);
        }

        // POST: Address/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
